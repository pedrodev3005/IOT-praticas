#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/ledc.h"
#include "esp_err.h"

#define BUZZER_PIN 2
#define BUZZER_FREQ_MIN 500
#define BUZZER_FREQ_MAX 2000
#define BUZZER_FREQ_STEP 100
#define BUZZER_STEP_DELAY_MS 40

void app_main(void) {
    // array com os pinos dos leds
    const int pinosLeds[] = {7,6,5,4};

    // Configuração do timer para os LEDs
    ledc_timer_config_t timer_leds = {
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .timer_num = LEDC_TIMER_0,
        .duty_resolution = LEDC_TIMER_10_BIT, // 0..1023
        .freq_hz = 1000,                   
        .clk_cfg = LEDC_AUTO_CLK,
    };
    ESP_ERROR_CHECK(ledc_timer_config(&timer_leds));

    // Configuração dos canais para os LEDs
    ledc_channel_config_t channel1 = {
        .gpio_num = pinosLeds[0],
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .channel = LEDC_CHANNEL_0,
        .intr_type = LEDC_INTR_DISABLE,
        .timer_sel = LEDC_TIMER_0,
        .duty = 0,
        .hpoint = 0,
    };

    ledc_channel_config_t channel2 = {
        .gpio_num = pinosLeds[1],
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .channel = LEDC_CHANNEL_1,
        .intr_type = LEDC_INTR_DISABLE,
        .timer_sel = LEDC_TIMER_0,
        .duty = 0,
        .hpoint = 0,
    };
    ledc_channel_config_t channel3 = {
        .gpio_num = pinosLeds[2],
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .channel = LEDC_CHANNEL_2,
        .intr_type = LEDC_INTR_DISABLE,
        .timer_sel = LEDC_TIMER_0,
        .duty = 0,
        .hpoint = 0,
    };

    ledc_channel_config_t channel4 = {
        .gpio_num = pinosLeds[3],
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .channel = LEDC_CHANNEL_3,
        .intr_type = LEDC_INTR_DISABLE,
        .timer_sel = LEDC_TIMER_0,
        .duty = 0,
        .hpoint = 0,
    };
    // Configura os canais dos LEDs
    ESP_ERROR_CHECK(ledc_channel_config(&channel1));
    ESP_ERROR_CHECK(ledc_channel_config(&channel2));
    ESP_ERROR_CHECK(ledc_channel_config(&channel3));
    ESP_ERROR_CHECK(ledc_channel_config(&channel4));

    ledc_timer_config_t timer_buzzer = {
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .timer_num = LEDC_TIMER_1,
        .duty_resolution = LEDC_TIMER_10_BIT, // 0..1023
        .freq_hz = 500, // frequência base de 500 Hz para o buzzer                   
        .clk_cfg = LEDC_AUTO_CLK,
    };
    ESP_ERROR_CHECK(ledc_timer_config(&timer_buzzer));

    ledc_channel_config_t channel_buzzer = {
        .gpio_num = BUZZER_PIN,
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .channel = LEDC_CHANNEL_4,
        .intr_type = LEDC_INTR_DISABLE,
        .timer_sel = LEDC_TIMER_1,
        .duty = 0,
        .hpoint = 0,
    };
    ESP_ERROR_CHECK(ledc_channel_config(&channel_buzzer));

    while (1) {
        // Loop para aumentar o brilho dos LEDs
        for (int i = 0; i <= 1023; i+=6)
        {
            ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0, i);
            ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0);
            ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_1, i);
            ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_1);
            ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_2, i);
            ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_2);
            ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_3, i);
            ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_3);
            vTaskDelay(pdMS_TO_TICKS(10));
        }
        // Loop para diminuir o brilho dos LEDs
         for (int i = 1023; i >= 0; i-=6)
        {
            ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0, i);
            ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0);
            ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_1, i);
            ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_1);
            ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_2, i);
            ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_2);
            ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_3,  i);
            ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_3);
            vTaskDelay(pdMS_TO_TICKS(10));
        }

        // Loop para tocar o buzzer
        ESP_ERROR_CHECK(ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_4, 512));
        ESP_ERROR_CHECK(ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_4));

        for (int i = BUZZER_FREQ_MIN; i <= BUZZER_FREQ_MAX; i += BUZZER_FREQ_STEP)
        {
            ledc_set_freq(LEDC_LOW_SPEED_MODE, LEDC_TIMER_1, i);
            vTaskDelay(pdMS_TO_TICKS(BUZZER_STEP_DELAY_MS));
        }

        for (int i = BUZZER_FREQ_MAX; i >= BUZZER_FREQ_MIN; i -= BUZZER_FREQ_STEP)
        {
            ledc_set_freq(LEDC_LOW_SPEED_MODE, LEDC_TIMER_1, i);
            vTaskDelay(pdMS_TO_TICKS(BUZZER_STEP_DELAY_MS));
        }

        ESP_ERROR_CHECK(ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_4, 0));
        ESP_ERROR_CHECK(ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_4));
        vTaskDelay(pdMS_TO_TICKS(150));

    }
}
