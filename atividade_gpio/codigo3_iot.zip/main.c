#include <stdbool.h>
#include <stdint.h>

#include "driver/gpio.h"
#include "driver/gptimer.h"
#include "driver/ledc.h"
#include "driver/uart.h"
#include "esp_attr.h"
#include "esp_err.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "freertos/timers.h"

#define LED1_PIN 7
#define LED2_PIN 6
#define BUZZER_PIN 2

#define BTN_A_PIN 9
#define BTN_B_PIN 10

#define LED_DUTY_ON 1023
#define LED_DUTY_OFF 0
#define BUZZER_DUTY_ON 512

#define UART_PORT UART_NUM_0
#define UART_RX_BUF_SIZE 256
#define UART_TX_BUF_SIZE 0
#define BUTTON_DEBOUNCE_MS 120
#define BUZZER_ON_TIME_MS 1500

// Eventos em uma única fila da aplicação.
typedef enum {
    APP_EVT_BTN_A,
    APP_EVT_BTN_B,
    APP_EVT_TIMER_2S,
    APP_EVT_UART_CMD,
    APP_EVT_BUZZER_OFF
} app_evt_id_t;

typedef struct {
    app_evt_id_t id;
    char cmd;
} app_evt_t;

static QueueHandle_t app_evt_queue;
static QueueHandle_t uart_evt_queue;
static gptimer_handle_t timer_2s;
static TimerHandle_t buzzer_off_timer;

static volatile bool button_b_enabled = true;
static bool led1_on = false;
static bool led2_on = false;
static bool buzzer_on = false;
static volatile TickType_t last_btn_a_tick = 0;
static volatile TickType_t last_btn_b_tick = 0;

// Atualiza duty de um canal LEDC de LED (liga/desliga).
static void set_led_duty(ledc_channel_t channel, bool on)
{
    uint32_t duty = on ? LED_DUTY_ON : LED_DUTY_OFF;
    ESP_ERROR_CHECK(ledc_set_duty(LEDC_LOW_SPEED_MODE, channel, duty));
    ESP_ERROR_CHECK(ledc_update_duty(LEDC_LOW_SPEED_MODE, channel));
}

// Liga/desliga buzzer no canal dedicado.
static void buzzer_set(bool on)
{
    uint32_t duty = on ? BUZZER_DUTY_ON : LED_DUTY_OFF;
    ESP_ERROR_CHECK(ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_2, duty));
    ESP_ERROR_CHECK(ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_2));
}

static void IRAM_ATTR gpio_isr_handler(void *arg)
{
    uint32_t pin = (uint32_t)(uintptr_t)arg;
    app_evt_t evt = {0};
    BaseType_t hp_task_woken = pdFALSE;
    TickType_t now = xTaskGetTickCountFromISR();
    TickType_t debounce_ticks = pdMS_TO_TICKS(BUTTON_DEBOUNCE_MS);

    // Debounce em ISR para reduzir eventos duplicados por bounce mecânico.
    if (pin == BTN_A_PIN) {
        if ((now - last_btn_a_tick) >= debounce_ticks) {
            last_btn_a_tick = now;
            evt.id = APP_EVT_BTN_A;
            xQueueSendFromISR(app_evt_queue, &evt, &hp_task_woken);
        }
    } else if (pin == BTN_B_PIN) {
        if (button_b_enabled && ((now - last_btn_b_tick) >= debounce_ticks)) {
            last_btn_b_tick = now;
            evt.id = APP_EVT_BTN_B;
            xQueueSendFromISR(app_evt_queue, &evt, &hp_task_woken);
        }
    }

    if (hp_task_woken) {
        portYIELD_FROM_ISR();
    }
}

static bool IRAM_ATTR timer_2s_alarm_cb(
    gptimer_handle_t timer,
    const gptimer_alarm_event_data_t *edata,
    void *user_data)
{
    (void)timer;
    (void)edata;
    (void)user_data;

    app_evt_t evt = {.id = APP_EVT_TIMER_2S, .cmd = 0};
    BaseType_t hp_task_woken = pdFALSE;
    xQueueSendFromISR(app_evt_queue, &evt, &hp_task_woken);
    return hp_task_woken == pdTRUE;
}

// LEDC usa 2 timers:
// - TIMER_0 para LED1/LED2
// - TIMER_1 para buzzer (500 Hz fixo)
static void ledc_init(void)
{
    ledc_timer_config_t led_timer = {
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .timer_num = LEDC_TIMER_0,
        .duty_resolution = LEDC_TIMER_10_BIT,
        .freq_hz = 1000,
        .clk_cfg = LEDC_AUTO_CLK,
    };
    ESP_ERROR_CHECK(ledc_timer_config(&led_timer));

    ledc_channel_config_t led1_ch = {
        .gpio_num = LED1_PIN,
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .channel = LEDC_CHANNEL_0,
        .intr_type = LEDC_INTR_DISABLE,
        .timer_sel = LEDC_TIMER_0,
        .duty = 0,
        .hpoint = 0,
    };
    ESP_ERROR_CHECK(ledc_channel_config(&led1_ch));

    ledc_channel_config_t led2_ch = {
        .gpio_num = LED2_PIN,
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .channel = LEDC_CHANNEL_1,
        .intr_type = LEDC_INTR_DISABLE,
        .timer_sel = LEDC_TIMER_0,
        .duty = 0,
        .hpoint = 0,
    };
    ESP_ERROR_CHECK(ledc_channel_config(&led2_ch));

    ledc_timer_config_t buzzer_timer = {
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .timer_num = LEDC_TIMER_1,
        .duty_resolution = LEDC_TIMER_10_BIT,
        .freq_hz = 500,
        .clk_cfg = LEDC_AUTO_CLK,
    };
    ESP_ERROR_CHECK(ledc_timer_config(&buzzer_timer));

    ledc_channel_config_t buzzer_ch = {
        .gpio_num = BUZZER_PIN,
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .channel = LEDC_CHANNEL_2,
        .intr_type = LEDC_INTR_DISABLE,
        .timer_sel = LEDC_TIMER_1,
        .duty = 0,
        .hpoint = 0,
    };
    ESP_ERROR_CHECK(ledc_channel_config(&buzzer_ch));
}

static void gpio_buttons_init(void)
{
    // Botões ativos em nível baixo com pull-up interno.
    gpio_config_t io_cfg = {
        .pin_bit_mask = (1ULL << BTN_A_PIN) | (1ULL << BTN_B_PIN),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_NEGEDGE,
    };
    ESP_ERROR_CHECK(gpio_config(&io_cfg));

    ESP_ERROR_CHECK(gpio_install_isr_service(0));
    ESP_ERROR_CHECK(gpio_isr_handler_add(BTN_A_PIN, gpio_isr_handler, (void *)(uintptr_t)BTN_A_PIN));
    ESP_ERROR_CHECK(gpio_isr_handler_add(BTN_B_PIN, gpio_isr_handler, (void *)(uintptr_t)BTN_B_PIN));
}

static void timer_2s_init(void)
{
    // GPTimer em 1 MHz para alarme periódico a cada 2 s.
    gptimer_config_t cfg = {
        .clk_src = GPTIMER_CLK_SRC_DEFAULT,
        .direction = GPTIMER_COUNT_UP,
        .resolution_hz = 1000000,
    };
    ESP_ERROR_CHECK(gptimer_new_timer(&cfg, &timer_2s));

    gptimer_event_callbacks_t cbs = {
        .on_alarm = timer_2s_alarm_cb,
    };
    ESP_ERROR_CHECK(gptimer_register_event_callbacks(timer_2s, &cbs, NULL));

    gptimer_alarm_config_t alarm_cfg = {
        .alarm_count = 2000000,
        .reload_count = 0,
        .flags.auto_reload_on_alarm = true,
    };
    ESP_ERROR_CHECK(gptimer_set_alarm_action(timer_2s, &alarm_cfg));
    ESP_ERROR_CHECK(gptimer_enable(timer_2s));
    ESP_ERROR_CHECK(gptimer_start(timer_2s));
}

static void uart_init(void)
{
    uart_config_t uart_cfg = {
        .baud_rate = 115200,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    ESP_ERROR_CHECK(
        uart_driver_install(UART_PORT, UART_RX_BUF_SIZE, UART_TX_BUF_SIZE, 10, &uart_evt_queue, 0));
    ESP_ERROR_CHECK(uart_param_config(UART_PORT, &uart_cfg));
}

// Timer one-shot do FreeRTOS que agenda o desligamento do buzzer.
static void buzzer_off_timer_cb(TimerHandle_t xTimer)
{
    (void)xTimer;
    app_evt_t evt = {.id = APP_EVT_BUZZER_OFF, .cmd = 0};
    xQueueSend(app_evt_queue, &evt, 0);
}

static void app_event_task(void *arg)
{
    (void)arg;
    app_evt_t evt;

    for (;;) {
        if (xQueueReceive(app_evt_queue, &evt, portMAX_DELAY) != pdTRUE) {
            continue;
        }

        switch (evt.id) {
        case APP_EVT_BTN_A:
            led1_on = !led1_on;
            set_led_duty(LEDC_CHANNEL_0, led1_on);
            break;

        case APP_EVT_BTN_B:
            if (button_b_enabled && !buzzer_on) {
                buzzer_on = true;
                buzzer_set(true);
                xTimerStart(buzzer_off_timer, 0);
            }
            break;

        case APP_EVT_TIMER_2S:
            led2_on = !led2_on;
            set_led_duty(LEDC_CHANNEL_1, led2_on);
            break;

        case APP_EVT_UART_CMD:
            if (evt.cmd == 'a') {
                button_b_enabled = false;
            } else if (evt.cmd == 'b') {
                button_b_enabled = true;
            }
            break;

        case APP_EVT_BUZZER_OFF:
            buzzer_on = false;
            buzzer_set(false);
            break;
        }
    }
}

static void uart_event_task(void *arg)
{
    (void)arg;
    uart_event_t uart_evt;
    uint8_t data[UART_RX_BUF_SIZE];

    for (;;) {
        if (xQueueReceive(uart_evt_queue, &uart_evt, portMAX_DELAY) != pdTRUE) {
            continue;
        }

        if (uart_evt.type == UART_DATA) {
            int len = uart_read_bytes(UART_PORT, data, sizeof(data), 0);
            for (int i = 0; i < len; ++i) {
                if (data[i] == 'a' || data[i] == 'b') {
                    app_evt_t evt = {
                        .id = APP_EVT_UART_CMD,
                        .cmd = (char)data[i],
                    };
                    xQueueSend(app_evt_queue, &evt, 0);
                }
            }
        }
    }
}

void app_main(void)
{
    // Fila principal de eventos da aplicação.
    app_evt_queue = xQueueCreate(20, sizeof(app_evt_t));
    buzzer_off_timer = xTimerCreate(
        "buzzer_off",
        pdMS_TO_TICKS(BUZZER_ON_TIME_MS),
        pdFALSE,
        NULL,
        buzzer_off_timer_cb);
    configASSERT(app_evt_queue != NULL);
    configASSERT(buzzer_off_timer != NULL);

    // Inicializações de periféricos e fontes de evento.
    ledc_init();
    gpio_buttons_init();
    timer_2s_init();
    uart_init();

    // Tasks de tratamento de eventos.
    xTaskCreate(app_event_task, "app_event_task", 4096, NULL, 10, NULL);
    xTaskCreate(uart_event_task, "uart_event_task", 4096, NULL, 9, NULL);
}
