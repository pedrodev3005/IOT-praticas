#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"


void app_main(void){
  const int pinosLeds[] = {7,6,5,4};

  //configurando os pinos como saída

  for (int i = 0; i < 4; i++) {
    gpio_reset_pin(pinosLeds[i]);
	esp_rom_gpio_pad_select_gpio(pinosLeds[i]);
	gpio_set_direction(pinosLeds[i],GPIO_MODE_OUTPUT);
}

	while(1){
		// fase 1:
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 4; j++)
			{
				if (1 & (i >> j))
				{
					gpio_set_level(pinosLeds[j], 1);
				}
				else
				{
					gpio_set_level(pinosLeds[j], 0);
				}
				vTaskDelay(500 / portTICK_PERIOD_MS);
			}
		
    }
	// apagando todos os leds para começar a fase 2
	for(int i = 0; i< 4; i++){
		gpio_set_level(pinosLeds[i], 0);
	}
	// fase 2:
	for (int j = 0; j < 4; j++){
			gpio_set_level(pinosLeds[j], 1);
			vTaskDelay(1000 / portTICK_PERIOD_MS);
	}

	for (int j = 3; j >= 0; j--){
		gpio_set_level(pinosLeds[j], 0);
		vTaskDelay(1000 / portTICK_PERIOD_MS);
	}
			
	}
}
